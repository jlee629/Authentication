//db.js Jungyu Lee, 301236221, Oct 18 2022

module.exports = 
{
    //"URI": "mongodb://127.0.0.1/book_store",
    "URI": "mongodb+srv://won:lfhHZrBy1Ik8guZj@mongodbserver.yfom0su.mongodb.net/business_contact?retryWrites=true&w=majority"
}